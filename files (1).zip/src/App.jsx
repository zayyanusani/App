import React, { useEffect, useState } from "react";
import ListComponent from "./components/ListComponent.jsx";

function App() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    setLoading(true);
    fetch("https://jsonplaceholder.typicode.com/posts")
      .then((res) => {
        if (!res.ok) throw new Error("API Error");
        return res.json();
      })
      .then((json) => {
        setData(json.slice(0, 10)); // Limit to 10 items
        setError("");
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div style={{ maxWidth: 600, margin: "2rem auto" }}>
      <h1>API Fetched Posts</h1>
      {loading && <div>Loading...</div>}
      {error && <div style={{ color: "red" }}>{error}</div>}
      {!loading && !error && (
        <ListComponent
          items={data}
          renderItem={(item) => (
            <div>
              <strong>{item.title}</strong>
              <div>{item.body}</div>
            </div>
          )}
          emptyMessage="No posts found."
        />
      )}
    </div>
  );
}

export default App;