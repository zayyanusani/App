import React from "react";

function ListComponent({ items, renderItem, emptyMessage = "No items found." }) {
  if (!items) return null;
  if (items.length === 0) return <div>{emptyMessage}</div>;

  return (
    <ul>
      {items.map((item, idx) => (
        <li key={item.id || idx}>{renderItem ? renderItem(item) : JSON.stringify(item)}</li>
      ))}
    </ul>
  );
}

export default ListComponent;