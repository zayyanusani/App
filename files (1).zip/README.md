# To-Do List Application (Node.js + Local Storage)

## Overview

A simple To-Do list web application built with Node.js (Express) for serving static files and browser localStorage for persistent to-do data.

## Features

- Add, complete, and remove tasks
- Tasks are stored in the browser’s `localStorage` (no backend database needed)
- Clear all tasks
- Responsive and clean UI

## How to Run

1. Install dependencies: