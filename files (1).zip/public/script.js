// Local Storage To-Do App

// Selectors
const todoForm = document.getElementById('todo-form');
const todoInput = document.getElementById('todo-input');
const todoList = document.getElementById('todo-list');
const clearBtn = document.getElementById('clear-btn');

// Retrieve todos from localStorage
function getTodos() {
    return JSON.parse(localStorage.getItem('todos') || '[]');
}

// Save todos to localStorage
function saveTodos(todos) {
    localStorage.setItem('todos', JSON.stringify(todos));
}

// Render todos
function renderTodos() {
    const todos = getTodos();
    todoList.innerHTML = '';
    todos.forEach((todo, idx) => {
        const li = document.createElement('li');
        li.textContent = todo.text;
        li.className = todo.completed ? 'completed' : '';
        li.addEventListener('click', () => toggleTodo(idx));
        
        const removeBtn = document.createElement('button');
        removeBtn.textContent = 'Remove';
        removeBtn.className = 'remove-btn';
        removeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            removeTodo(idx);
        });
        li.appendChild(removeBtn);

        todoList.appendChild(li);
    });
}

// Add todo
todoForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const todos = getTodos();
    todos.push({ text: todoInput.value, completed: false });
    saveTodos(todos);
    todoInput.value = '';
    renderTodos();
});

// Toggle completed
function toggleTodo(idx) {
    const todos = getTodos();
    todos[idx].completed = !todos[idx].completed;
    saveTodos(todos);
    renderTodos();
}

// Remove todo
function removeTodo(idx) {
    const todos = getTodos();
    todos.splice(idx, 1);
    saveTodos(todos);
    renderTodos();
}

// Clear all
clearBtn.addEventListener('click', () => {
    if (confirm('Clear all tasks?')) {
        localStorage.removeItem('todos');
        renderTodos();
    }
});

// Initial render
renderTodos();